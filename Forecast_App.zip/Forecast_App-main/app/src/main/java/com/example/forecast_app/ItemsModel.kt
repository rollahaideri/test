package com.example.forecast_app

data class ItemsModel (val cityName: String, val temp: String){
}