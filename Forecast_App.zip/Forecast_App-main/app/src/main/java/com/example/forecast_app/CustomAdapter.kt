package com.example.forecast_app

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.*
import kotlin.collections.ArrayList

internal class CustomAdapter(private var itemsList: ArrayList<ItemsModel>) :
    RecyclerView.Adapter<CustomAdapter.MyViewHolder>(){

    // Init - Extend interface
    private lateinit var mListener : OnItemClickListener
    var itemFilterList = ArrayList<ItemsModel>()



    // ???
    init {
        itemFilterList = itemsList
    }

    // Create interface
    interface OnItemClickListener{
        fun onItemClick(position: Int)
    }

    // Method Definition
    fun setOnItemClickListener(listener: OnItemClickListener) {
        mListener = listener


    }
        internal inner class MyViewHolder(view: View, listener: OnItemClickListener) : RecyclerView.ViewHolder(view) {
            var itemTextView: TextView = view.findViewById(R.id.cityName)
            var temp: TextView = view.findViewById(R.id.temp)

            init {
                itemView.setOnClickListener{
                    listener.onItemClick(adapterPosition)
                }
            }
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_item, parent, false)
        return MyViewHolder(itemView, mListener)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val ItemsModel = itemFilterList[position]
        holder.itemTextView.text = ItemsModel.cityName
        holder.temp.text = ItemsModel.temp
    }

    override fun getItemCount(): Int {
        // return itemsList.size
        return itemFilterList.size
    }

    fun getFilter() : Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val charSearch = constraint.toString()
                itemFilterList = if (charSearch.isEmpty()) {
                    itemsList
                } else {
                    val resultList = ArrayList<ItemsModel>()
//                    for (row in itemsList) {
//                        if (row.temp.lowercase(Locale.ROOT).contains(charSearch.lowercase(Locale.ROOT))) {
//                            resultList.add(row)
//                        }
//                    }
                    resultList
                }

                // Is a must - For filtering
                val filterResults = FilterResults()
                filterResults.values = itemFilterList
                return filterResults
            }

            @SuppressLint("notifyDataSetChanged")
            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                if (results != null) {
                     results.values as ArrayList<ItemsModel>
                    notifyDataSetChanged()
                }
            }
        }
    }

    }







